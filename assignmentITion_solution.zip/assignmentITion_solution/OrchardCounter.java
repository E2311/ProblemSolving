import java.util.ArrayList;
import java.util.List;

/**
 * Problem 3: Compute the sizes of all orchards in a matrix.
 * An orchard is a connected region of trees ('T') vertically, horizontally, or diagonally.
 * 
 * Approach:
 * We treat the matrix as a graph where each 'T' is a node and connected 'T's are edges.
 * We iterate through every cell in the matrix. When we find a 'T' that hasn't been visited:
 * 1. Start a Depth First Search (DFS) from that cell.
 * 2. In DFS, visit all 8 neighboring cells (horizontal, vertical, diagonal).
 * 3. Count the number of 'T's in this connected component.
 * 4. Mark visited cells to avoid re-counting.
 * 5. Add the final count to our list of orchard sizes.
 */
public class OrchardCounter {

    public static void main(String[] args) {
        char[][] matrix = {
            {'O', 'T', 'O', 'O'},
            {'O', 'T', 'O', 'T'},
            {'T', 'T', 'O', 'T'},
            {'O', 'T', 'O', 'T'}
        };

        List<Integer> sizes = findOrchardSizes(matrix);
        
        System.out.print("Output: ");
        for (int i = 0; i < sizes.size(); i++) {
            System.out.print(sizes.get(i) + (i == sizes.size() - 1 ? "" : ", "));
        }
        System.out.println();
    }

    public static List<Integer> findOrchardSizes(char[][] matrix) {
        List<Integer> sizes = new ArrayList<>();
        if (matrix == null || matrix.length == 0) return sizes;

        int rows = matrix.length;
        int cols = matrix[0].length;
        boolean[][] visited = new boolean[rows][cols];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                // If we find a tree 'T' that is not visited, it's a new orchard
                if (matrix[i][j] == 'T' && !visited[i][j]) {
                    int size = dfs(matrix, visited, i, j);
                    sizes.add(size);
                }
            }
        }
        return sizes;
    }

    private static int dfs(char[][] matrix, boolean[][] visited, int r, int c) {
        // Boundary checks and base cases
        if (r < 0 || r >= matrix.length || c < 0 || c >= matrix[0].length || 
            matrix[r][c] == 'O' || visited[r][c]) {
            return 0;
        }

        // Mark current cell as visited
        visited[r][c] = true;
        int count = 1;

        // Check all 8 directions
        int[] dr = {-1, -1, -1, 0, 0, 1, 1, 1};
        int[] dc = {-1, 0, 1, -1, 1, -1, 0, 1};

        for (int i = 0; i < 8; i++) {
            count += dfs(matrix, visited, r + dr[i], c + dc[i]);
        }

        return count;
    }
}
