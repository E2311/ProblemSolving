import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * Problem 2: Fetch Bitcoin rate in INR from CoinGecko API and print it in words.
 * 
 * Approach:
 * 1. Use Java's HttpClient to make a GET request to the CoinGecko API.
 * 2. Parse the JSON response manually to extract the INR value (to avoid external dependencies).
 * 3. Implement a conversion logic from numbers to Indian Currency words (Lakh, Crore system).
 */
public class BitcoinRateInWords {

    public static void main(String[] args) {
        String apiUrl = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd,inr,eur";
        
        try {
            // Create HTTP Client and Request
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(apiUrl))
                    .GET()
                    .build();

            // Send request and get response
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String jsonResponse = response.body();

            // Extract INR value manually 
            // Expected format: {"bitcoin":{"usd":...,"inr":7823123,"eur":...}}
            long inrRate = parseInrValue(jsonResponse);

            if (inrRate != -1) {
                System.out.println("Bitcoin Rate in INR: " + inrRate);
                System.out.println("In Words: " + convertToIndianWords(inrRate));
            } else {
                System.out.println("Could not parse Bitcoin rate.");
            }

        } catch (Exception e) {
            System.out.println("Error fetching data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Extracts the value of "inr" from the JSON string.
     */
    private static long parseInrValue(String json) {
        try {
            String key = "\"inr\":";
            int startIndex = json.indexOf(key) + key.length();
            int endIndex = json.indexOf(",", startIndex);
            if (endIndex == -1) {
                endIndex = json.indexOf("}", startIndex);
            }
            String valueStr = json.substring(startIndex, endIndex).trim();
            return (long) Double.parseDouble(valueStr); // Bitcoin price can have decimals, but we'll convert to long as per example
        } catch (Exception e) {
            return -1;
        }
    }

    /**
     * Converts a number into words using the Indian numbering system (Lakh, Crore).
     */
    public static String convertToIndianWords(long n) {
        if (n == 0) return "Zero";

        String[] units = {"", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", 
                         "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"};
        String[] tens = {"", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"};

        return helper(n, units, tens).trim();
    }

    private static String helper(long n, String[] units, String[] tens) {
        String res = "";
        if (n >= 10000000) {
            res += helper(n / 10000000, units, tens) + " Crore ";
            n %= 10000000;
        }
        if (n >= 100000) {
            res += helper(n / 100000, units, tens) + " Lakh ";
            n %= 100000;
        }
        if (n >= 1000) {
            res += helper(n / 1000, units, tens) + " Thousand ";
            n %= 1000;
        }
        if (n >= 100) {
            res += units[(int)(n / 100)] + " Hundred ";
            n %= 100;
        }
        if (n > 0) {
            if (n < 20) {
                res += units[(int)n];
            } else {
                res += tens[(int)(n / 10)] + " " + units[(int)(n % 10)];
            }
        }
        return res;
    }
}
