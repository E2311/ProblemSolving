/**
 * Problem 1: Print all nodes at distance k from the root of a binary tree recursively.
 * 
 * Approach:
 * We use a recursive function `printNodesAtDistanceK`. 
 * - If the current node is null, we return.
 * - If k is 0, it means we have reached the desired depth, so we print the node's data.
 * - If k > 0, we recursively call the function for both left and right children, 
 *   decrementing k by 1 at each level until it reaches 0.
 */

class Node {
    int data;
    Node left;
    Node right;

    Node(int data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }
}

public class BinaryTreeDistance {

    /**
     * Recursively prints nodes at distance k from the given node.
     * @param node The current node
     * @param k The remaining distance to travel
     */
    public static void printNodesAtDistanceK(Node node, int k) {
        // Base case: if node is null, just return
        if (node == null) {
            return;
        }

        // If distance becomes 0, we found a node at distance k
        if (k == 0) {
            System.out.print(node.data + " ");
            return;
        }

        // Recurse to left and right subtrees with distance k-1
        printNodesAtDistanceK(node.left, k - 1);
        printNodesAtDistanceK(node.right, k - 1);
    }

    public static void main(String[] args) {
        /*
               1
             /   \
            2     3
           / \   /
          4   5 6
        */
        Node root = new Node(1);
        root.left = new Node(2);
        root.right = new Node(3);
        root.left.left = new Node(4);
        root.left.right = new Node(5);
        root.right.left = new Node(6);

        int k = 2;
        System.out.print("Nodes at distance " + k + " from root: ");
        printNodesAtDistanceK(root, k);
        System.out.println();
    }
}
